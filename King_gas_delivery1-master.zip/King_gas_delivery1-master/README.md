# King_gas_delivery1
## Author
Elly Oketch
Jeremiah Juma
Serah Wakaba
Owiye Vincent
## Description
Its a website that explains how to deliver gas cylinder and extra cooking accessories to client after order. 
### Prerequisites
You need to have git installed
You can install it with the following command in your terminal
`$ sudo apt install git-all`
### Setup
To access this project on your local files, you can clone it using these steps
1. Open your terminal
1. Use this command to clone https://github.com/vinowiye/King_gas_delivery1.git
1. This will clone the repositoty into your local folder
1. Dairy_Farm_Business:)
### Technologies Used
1. HTML
1. CSS
1. Javascript
1. Git
### Live Site
View [live](https://vinowiye.github.io/King_gas_delivery1/)
### Licence
This project is under the [MIT](LICENSE) licence  
